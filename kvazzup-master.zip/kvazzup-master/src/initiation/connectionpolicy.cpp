#include "connectionpolicy.h"

#include <QSettings>


ConnectionPolicy::ConnectionPolicy()
{

}




