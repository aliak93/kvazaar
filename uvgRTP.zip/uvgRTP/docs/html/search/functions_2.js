var searchData=
[
  ['destroy_5fsession_83',['destroy_session',['../classuvgrtp_1_1context.html#a61daf2f3cdcdf2542ee997ab6de5efa9',1,'uvgrtp::context']]],
  ['destroy_5fstream_84',['destroy_stream',['../classuvgrtp_1_1session.html#a291629a3bfb910463b88d8edb3984149',1,'uvgrtp::session']]]
];
