var searchData=
[
  ['configure_5fctx_1',['configure_ctx',['../classuvgrtp_1_1media__stream.html#addf1cde9cb8c4e4af3160ce24c4288a5',1,'uvgrtp::media_stream']]],
  ['context_2',['context',['../classuvgrtp_1_1context.html#a98be18c2848404549cfadf910ba1573a',1,'uvgrtp::context::context()'],['../classuvgrtp_1_1context.html',1,'uvgrtp::context']]],
  ['create_5fsession_3',['create_session',['../classuvgrtp_1_1context.html#aa109aa2a419933359d225d19bcf3b2f9',1,'uvgrtp::context::create_session(std::string addr)'],['../classuvgrtp_1_1context.html#a0007eebfd5131bf0930cfedc0c4018e8',1,'uvgrtp::context::create_session(std::string remote_addr, std::string local_addr)']]],
  ['create_5fstream_4',['create_stream',['../classuvgrtp_1_1session.html#a71aad1226214b1b0b1ba60a46c048ab2',1,'uvgrtp::session']]]
];
